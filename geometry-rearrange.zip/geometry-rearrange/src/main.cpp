#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/binding/CCMenuItemSpriteExtra.hpp>
#include <Geode/ui/BasedButtonSprite.hpp>
#include <Geode/loader/Mod.hpp>

using namespace geode::prelude;

// Simple saved position helper
struct NodePos {
    float x = 0.f;
    float y = 0.f;
};

// Global-ish edit mode flag (saved too)
static bool s_editMode = false;
static CCNode* s_draggingNode = nullptr;
static CCPoint s_dragOffset;

// Load / save helpers using Geode saved values
NodePos loadPos(std::string const& key) {
    return Mod::get()->getSavedValue<NodePos>(key, NodePos{});
}

void savePos(std::string const& key, float x, float y) {
    Mod::get()->setSavedValue(key, NodePos{x, y});
}

// Make NodePos serializable
template <>
struct matjson::Serialize<NodePos> {
    static geode::Result<NodePos> fromJson(matjson::Value const& value) {
        auto x = value["x"].asDouble().unwrapOr(0.0);
        auto y = value["y"].asDouble().unwrapOr(0.0);
        return Ok(NodePos{static_cast<float>(x), static_cast<float>(y)});
    }
    static matjson::Value toJson(NodePos const& value) {
        return matjson::makeObject({
            {"x", value.x},
            {"y", value.y}
        });
    }
};

class $modify(MenuLayer) {
    struct Fields {
        CCMenuItemSpriteExtra* m_editToggle = nullptr;
        bool m_listenersAdded = false;
    };

    bool init() {
        if (!MenuLayer::init()) return false;

        // restore edit mode state
        s_editMode = Mod::get()->getSavedValue<bool>("edit-mode", false);

        // create a simple toggle button (top-right-ish)
        auto sprOn  = ButtonSprite::create("Edit ON", "bigFont.fnt", "GJ_button_02.png", 0.5f);
        auto sprOff = ButtonSprite::create("Edit OFF", "bigFont.fnt", "GJ_button_01.png", 0.5f);

        auto btn = CCMenuItemSpriteExtra::create(
            s_editMode ? sprOn : sprOff,
            this,
            menu_selector(MenuLayer::onToggleEdit)
        );
        btn->setID("geometry-rearrange-toggle"_spr);
        btn->setPosition({ CCDirector::get()->getWinSize().width - 60.f, CCDirector::get()->getWinSize().height - 40.f });

        auto menu = CCMenu::create();
        menu->setID("geometry-rearrange-menu"_spr);
        menu->setPosition({0, 0});
        menu->addChild(btn);
        this->addChild(menu, 999);

        m_fields->m_editToggle = btn;

        // apply any previously saved positions to common buttons
        this->applySavedPositions();

        // touch handling for edit mode
        this->setTouchEnabled(true);
        this->registerWithTouchDispatcher();

        return true;
    }

    void onToggleEdit(CCObject*) {
        s_editMode = !s_editMode;
        Mod::get()->setSavedValue("edit-mode", s_editMode);

        // swap button look
        if (m_fields->m_editToggle) {
            auto spr = ButtonSprite::create(
                s_editMode ? "Edit ON" : "Edit OFF",
                "bigFont.fnt",
                s_editMode ? "GJ_button_02.png" : "GJ_button_01.png",
                0.5f
            );
            m_fields->m_editToggle->setNormalImage(spr);
        }

        log::info("Geometry Rearrange edit mode: {}", s_editMode ? "ON" : "OFF");
    }

    void applySavedPositions() {
        // example: try to move a few known nodes if we have saved data
        // (node-ids dependency helps a lot here)
        auto tryMove = [&](std::string const& id, std::string const& saveKey) {
            if (auto node = this->getChildByIDRecursive(id)) {
                auto pos = loadPos(saveKey);
                if (pos.x != 0.f || pos.y != 0.f) {
                    node->setPosition(pos.x, pos.y);
                }
            }
        };

        tryMove("play-button", "pos-play");
        tryMove("icon-kit-button", "pos-icon");
        tryMove("editor-button", "pos-editor");
        // add more IDs as needed
    }

    // --- Touch handling for drag & drop ---
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (!s_editMode) return MenuLayer::ccTouchBegan(touch, event);

        auto loc = touch->getLocation();
        // simple hit test – walk children looking for something under the finger
        s_draggingNode = nullptr;

        // prioritise menu items / sprites
        for (auto child : CCArrayExt<CCNode*>(this->getChildren())) {
            if (!child->isVisible()) continue;
            auto box = child->boundingBox();
            // convert to world-ish
            auto worldPos = this->convertToWorldSpace(child->getPosition());
            // rough check
            if (box.containsPoint(this->convertToNodeSpace(loc))) {
                s_draggingNode = child;
                s_dragOffset = ccpSub(child->getPosition(), this->convertToNodeSpace(loc));
                break;
            }
        }

        return s_draggingNode != nullptr || MenuLayer::ccTouchBegan(touch, event);
    }

    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (s_editMode && s_draggingNode) {
            auto loc = this->convertToNodeSpace(touch->getLocation());
            s_draggingNode->setPosition(ccpAdd(loc, s_dragOffset));
            return;
        }
        MenuLayer::ccTouchMoved(touch, event);
    }

    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (s_editMode && s_draggingNode) {
            // save the new position under a key based on node ID if possible
            std::string key = "pos-" + (s_draggingNode->getID().empty()
                ? std::to_string(reinterpret_cast<uintptr_t>(s_draggingNode))
                : std::string(s_draggingNode->getID()));

            savePos(key, s_draggingNode->getPositionX(), s_draggingNode->getPositionY());
            log::info("Saved position for {} -> ({}, {})", key,
                      s_draggingNode->getPositionX(), s_draggingNode->getPositionY());

            s_draggingNode = nullptr;
            return;
        }
        MenuLayer::ccTouchEnded(touch, event);
    }

    void registerWithTouchDispatcher() override {
        CCTouchDispatcher::get()->addTargetedDelegate(this, -128, true);
    }
};

// just so the mod loads cleanly
$on_mod(Loaded) {
    log::info("Geometry Rearrange loaded – drag mode ready");
}
